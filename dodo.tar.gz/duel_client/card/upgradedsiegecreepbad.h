#ifndef UPGRADEDSIEGECREEPBAD_H
#define UPGRADEDSIEGECREEPBAD_H

#include <card.h>

class UpgradedSiegeCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE UpgradedSiegeCreepBad();
};

#endif // UPGRADEDSIEGECREEPBAD_H
