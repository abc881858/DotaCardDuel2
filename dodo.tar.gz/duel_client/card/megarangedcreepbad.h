#ifndef MEGARANGEDCREEPBAD_H
#define MEGARANGEDCREEPBAD_H

#include <card.h>

class MegaRangedCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE MegaRangedCreepBad();
};

#endif // MEGARANGEDCREEPBAD_H
