#include "upgradedsiegecreepbad.h"

UpgradedSiegeCreepBad::UpgradedSiegeCreepBad()
{
    ISDN = 12;
    name = "UpgradedSiegeCreepBad";
    description = tr("UpgradedSiegeCreepBad"); //高级攻城车（夜魇）
    attribute = Dark_Attribute;
    level = 6;
    kind = NormalMonster_Kind;
    type = Machine_Type;
    ATK = 1500;
    DEF = 3000;
}
