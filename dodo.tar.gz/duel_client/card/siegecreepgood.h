#ifndef SIEGECREEPGOOD_H
#define SIEGECREEPGOOD_H

#include <card.h>

class SiegeCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE SiegeCreepGood();
};

#endif // SIEGECREEPGOOD_H
