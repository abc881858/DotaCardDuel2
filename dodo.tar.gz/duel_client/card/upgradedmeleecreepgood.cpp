#include "upgradedmeleecreepgood.h"

UpgradedMeleeCreepGood::UpgradedMeleeCreepGood()
{
    ISDN = 7;
    name = "UpgradedMeleeCreepGood";
    description = tr("UpgradedMeleeCreepGood"); //高级近程兵（天辉）
    attribute = Light_Attribute;
    level = 5;
    kind = NormalMonster_Kind;
    type = Warrior_Type;
    ATK = 2300;
    DEF = 2200;
}
