#ifndef UPGRADEDRANGEDCREEPBAD_H
#define UPGRADEDRANGEDCREEPBAD_H

#include <card.h>

class UpgradedRangedCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE UpgradedRangedCreepBad();
};

#endif // UPGRADEDRANGEDCREEPBAD_H
