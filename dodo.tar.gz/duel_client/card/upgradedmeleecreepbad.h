#ifndef UPGRADEDMELEECREEPBAD_H
#define UPGRADEDMELEECREEPBAD_H

#include <card.h>

class UpgradedMeleeCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE UpgradedMeleeCreepBad();
};

#endif // UPGRADEDMELEECREEPBAD_H
