#include "megarangedcreepbad.h"

MegaRangedCreepBad::MegaRangedCreepBad()
{
    ISDN = 16;
    name = "MegaRangedCreepBad";
    description = tr("MegaRangedCreepBad"); //超级远程兵（夜魇）
    attribute = Dark_Attribute;
    level = 7;
    kind = NormalMonster_Kind;
    type = Warrior_Type;
    ATK = 3200;
    DEF = 3300;
}
