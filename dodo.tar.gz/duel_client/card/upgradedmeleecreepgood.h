#ifndef UPGRADEDMELEECREEPGOOD_H
#define UPGRADEDMELEECREEPGOOD_H

#include <card.h>

class UpgradedMeleeCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE UpgradedMeleeCreepGood();
};

#endif // UPGRADEDMELEECREEPGOOD_H
