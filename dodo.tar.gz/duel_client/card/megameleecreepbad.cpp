#include "megameleecreepbad.h"

MegaMeleeCreepBad::MegaMeleeCreepBad()
{
    ISDN = 14;
    name = "MegaMeleeCreepBad";
    description = tr("MegaMeleeCreepBad"); //超级近战兵（夜魇）
    attribute = Dark_Attribute;
    level = 7;
    kind = NormalMonster_Kind;
    type = Warrior_Type;
    ATK = 3300;
    DEF = 3200;
}
