#ifndef MEGARANGEDCREEPGOOD_H
#define MEGARANGEDCREEPGOOD_H

#include <card.h>

class MegaRangedCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE MegaRangedCreepGood();
};

#endif // MEGARANGEDCREEPGOOD_H
