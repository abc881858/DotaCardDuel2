#ifndef RANGEDCREEPGOOD_H
#define RANGEDCREEPGOOD_H

#include <card.h>

class RangedCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE RangedCreepGood();
};

#endif // RANGEDCREEPGOOD_H
