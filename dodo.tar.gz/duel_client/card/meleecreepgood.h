#ifndef MELEECREEPGOOD_H
#define MELEECREEPGOOD_H

#include <card.h>

class MeleeCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE MeleeCreepGood();
};

#endif // MELEECREEPGOOD_H
