#include "upgradedmeleecreepbad.h"

UpgradedMeleeCreepBad::UpgradedMeleeCreepBad()
{
    ISDN = 8;
    name = "UpgradedMeleeCreepBad";
    description = tr("UpgradedMeleeCreepBad"); //高级近战兵（夜魇）
    attribute = Dark_Attribute;
    level = 5;
    kind = NormalMonster_Kind;
    type = Warrior_Type;
    ATK = 2300;
    DEF = 2200;
}
