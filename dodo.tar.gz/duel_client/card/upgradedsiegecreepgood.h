#ifndef UPGRADEDSIEGECREEPGOOD_H
#define UPGRADEDSIEGECREEPGOOD_H

#include <card.h>

class UpgradedSiegeCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE UpgradedSiegeCreepGood();
};

#endif // UPGRADEDSIEGECREEPGOOD_H
