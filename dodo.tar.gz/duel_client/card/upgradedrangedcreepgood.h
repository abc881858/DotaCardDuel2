#ifndef UPGRADEDRANGEDCREEPGOOD_H
#define UPGRADEDRANGEDCREEPGOOD_H

#include <card.h>

class UpgradedRangedCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE UpgradedRangedCreepGood();
};

#endif // UPGRADEDRANGEDCREEPGOOD_H
