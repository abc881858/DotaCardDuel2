#ifndef MEGAMELEECREEPGOOD_H
#define MEGAMELEECREEPGOOD_H

#include <card.h>

class MegaMeleeCreepGood : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE MegaMeleeCreepGood();
};

#endif // MEGAMELEECREEPGOOD_H
