#ifndef RANGEDCREEPBAD_H
#define RANGEDCREEPBAD_H

#include <card.h>

class RangedCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE RangedCreepBad();
};

#endif // RANGEDCREEPBAD_H
