#ifndef MEGAMELEECREEPBAD_H
#define MEGAMELEECREEPBAD_H

#include <card.h>

class MegaMeleeCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE MegaMeleeCreepBad();
};

#endif // MEGAMELEECREEPBAD_H
