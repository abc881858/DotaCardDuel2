#ifndef SIEGECREEPBAD_H
#define SIEGECREEPBAD_H

#include <card.h>

class SiegeCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE SiegeCreepBad();
};

#endif // SIEGECREEPBAD_H
