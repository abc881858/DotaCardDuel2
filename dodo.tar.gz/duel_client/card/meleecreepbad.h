#ifndef MELEECREEPBAD_H
#define MELEECREEPBAD_H

#include <card.h>

class MeleeCreepBad : public Card
{
    Q_OBJECT

public:
    Q_INVOKABLE MeleeCreepBad();
};

#endif // MELEECREEPBAD_H
