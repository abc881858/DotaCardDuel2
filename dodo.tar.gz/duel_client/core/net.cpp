#include "net.h"
#include <QHostAddress>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonValue>
#include <QUrl>

Q_GLOBAL_STATIC(Net, net)

Net* Net::instance()
{
    return net();
}

void Net::initialize()
{
    client = new QWebSocket;
    client->open(QUrl("ws://localhost:7720"));
    //    client->open(QUrl("ws://47.101.204.243:7720"));
    connect(client, SIGNAL(connected()), this, SLOT(connected()));
    connect(client, SIGNAL(binaryMessageReceived(QByteArray)), this, SLOT(readFromServer(QByteArray)));
}

void Net::connected()
{
    qDebug() << "hostConnectedServer";
    emit hostConnectedServer();
}

void Net::readFromServer(const QByteArray& json)
{
    QJsonDocument jsonDoucment = QJsonDocument::fromJson(json);
    QJsonObject object = jsonDoucment.object();

    QString command = object["command"].toString();

    if(command == "start_game_blue")
    {
        emit command_start_game_blue();
    }
    if(command == "start_game_red")
    {
        emit command_start_game_red();
    }
}

void Net::writeToServer(const QJsonObject &jsonObject)
{
    QJsonDocument jsonDoucment(jsonObject);
    QByteArray byteArray = jsonDoucment.toJson(QJsonDocument::Compact); //压缩的json
    client->sendBinaryMessage(byteArray);
}

//void Net::writeToServer(int command)
//{
//    QJsonObject jsonObject;
//    jsonObject.insert("command", command);
//    writeToServer(jsonObject);
//}

//    QJsonObject jsonObject;
//    jsonObject.insert("command", 1000);
//    writeToServer(jsonObject);

//    QString request = object["request"].toString();
//    if (request.isEmpty())
//    {
//        return;
//    }

//    request.prepend("request_");
//    QJsonObject parameter = object["parameter"].toObject();
//    if (parameter.isEmpty())
//    {
//        QMetaObject::invokeMethod(this, request.toLatin1().data());
//    }
//    else
//    {
//        QMetaObject::invokeMethod(this, request.toLatin1().data(), Q_ARG(QJsonObject, parameter));
//    }

