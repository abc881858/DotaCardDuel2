#ifndef NET_H
#define NET_H

#include <QJsonObject>
#include <QWebSocket>

#if defined(qNet)
#undef qNet
#endif
#define qNet (Net::instance())

class Net : public QObject
{
    Q_OBJECT

public:
    static Net* instance();
    void initialize();
    void writeToServer(const QJsonObject& jsonObject);

private:
    QWebSocket* client;

public slots:
    void connected();
    void readFromServer(const QByteArray& json);

signals:
    void hostConnectedServer();
    void command_start_game_blue();
    void command_start_game_red();
};

#endif // NET_H
