#include "player.h"
#include "net.h"

Player::Player(QObject *parent) : QObject(parent)
{
}

void Player::setRole(Player::RoleFlag role)
{
    m_role = role;
}

Player::RoleFlag Player::role() const
{
    return m_role;
}

//void Player::setColor(Player::ColorFlag color)
//{
//    m_color = color;
//}

//Player::ColorFlag Player::color() const
//{
//    return m_color;
//}

void Player::setStatus(Player::StatusFlag status)
{
    m_status = status;
}

Player::StatusFlag Player::status() const
{
    return m_status;
}

void Player::start_game_blue()
{
    //do somthing
    //......
    QJsonObject jsonObject;
    jsonObject.insert("command", "start_game_blue_over");
    qNet->writeToServer(jsonObject);
}

void Player::start_game_red()
{
    //do somthing
    //......
    QJsonObject jsonObject;
    jsonObject.insert("command", "start_game_red_over");
    qNet->writeToServer(jsonObject);
}
