#ifndef GAME_H
#define GAME_H

//给单例 Dota 设置一个宏，方便使用
#if defined(qGame)
#undef qGame
#endif
#define qGame (Game::instance())

#include <QObject>
#include <player.h>

class Game : public QObject
{
    Q_OBJECT

public:
    static Game* instance();
    void initialize();
    enum PhaseFlag
    {
        No_Phase,
        Prepare_Phase,
        Start_Phase,
        Blue_Draw_Phase,
        Blue_Standby_Phase,
        Blue_Main1_Phase,
        Blue_Battle_Phase,
        Blue_Main2_Phase,
        Blue_End_Phase,
        Red_Draw_Phase,
        Red_Standby_Phase,
        Red_Main1_Phase,
        Red_Battle_Phase,
        Red_Main2_Phase,
        Red_End_Phase
    };
    Q_ENUM(PhaseFlag)
    void setPhase(PhaseFlag phase);
    PhaseFlag phase() const;

private:
    PhaseFlag m_phase{No_Phase};
    Player *hostPlayer;
    Player *remotePlayer;

signals:

};

#endif // GAME_H
