#include "card.h"

Card::Card()
{
}
