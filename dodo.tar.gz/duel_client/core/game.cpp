#include "game.h"
#include "net.h"

Q_GLOBAL_STATIC(Game, game)

Game* Game::instance()
{
    return game();
}

void Game::initialize()
{
    hostPlayer = new Player(this);
    hostPlayer->setRole(Player::Host_Role);

    remotePlayer = new Player(this);
    remotePlayer->setRole(Player::Remote_Role);

    connect(qNet, &Net::hostConnectedServer, [=]{
        m_phase = Prepare_Phase;
    });

    connect(qNet, &Net::command_start_game_blue, [=]{
        m_phase = Start_Phase;
        hostPlayer->start_game_blue();
    });

    connect(qNet, &Net::command_start_game_red, [=]{
        m_phase = Start_Phase;
        hostPlayer->start_game_red();
    });
}

void Game::setPhase(Game::PhaseFlag phase)
{
    m_phase = phase;
}

Game::PhaseFlag Game::phase() const
{
    return m_phase;
}

//void Game::startGame()
//{
//    qDebug() << "startGame!";
//    //show animation
//}
