#ifndef PLAYER_H
#define PLAYER_H

#include <QObject>

class Player : public QObject
{
    Q_OBJECT

public:
    enum RoleFlag
    {
        No_Role,
        Host_Role,
        Remote_Role
    };
    Q_ENUM(RoleFlag)

//    enum ColorFlag
//    {
//        No_Color,
//        Blue_Color,
//        Red_Color
//    };
//    Q_ENUM(ColorFlag)

    enum StatusFlag
    {
        No_Status,
//        Prepare_Status,
        Working_Status,
        Waiting_Status
    };
    Q_ENUM(StatusFlag)

    explicit Player(QObject *parent = nullptr);

    void setRole(RoleFlag role);
    RoleFlag role() const;

//    void setColor(ColorFlag color);
//    ColorFlag color() const;

    void setStatus(StatusFlag status);
    StatusFlag status() const;

    void start_game_blue();
    void start_game_red();

private:
    RoleFlag m_role{No_Role};
//    ColorFlag m_color{No_Color};
    StatusFlag m_status{No_Status};

signals:

};

#endif // PLAYER_H
