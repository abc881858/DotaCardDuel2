#include "player.h"

Player::Player(QObject *parent) : QObject(parent)
{
}

void Player::setSocket(QWebSocket *socket)
{
    m_socket = socket;
    connect(socket, &QWebSocket::binaryMessageReceived, this, &Player::readFromClient);
}

QWebSocket *Player::socket()
{
    return m_socket;
}

void Player::setOpponent(QWebSocket *socket)
{
    u_socket = socket;
}

void Player::command_start_game_blue()
{
    QJsonObject jsonObject;
    jsonObject.insert("command", "start_game_blue");
    QJsonDocument jsonDoucment(jsonObject);
    QByteArray json = jsonDoucment.toJson(QJsonDocument::Compact);
    m_socket->sendBinaryMessage(json);
}

void Player::readFromClient(const QByteArray &jsonFrom)
{
    QJsonDocument jsonDoucmentFrom = QJsonDocument::fromJson(jsonFrom);
    QJsonObject jsonObjectFrom = jsonDoucmentFrom.object();

    QString commandFrom = jsonObjectFrom["command"].toString();
    QString commandTo;

    if(commandFrom == "start_game_blue_over")
    {
        commandTo = "start_game_red";
    }
    if(commandFrom == "start_game_red_over")
    {
        commandTo = "draw_phase_blue";
    }

    QJsonObject jsonObjectTo;
    jsonObjectTo.insert("command", commandTo);
    QJsonDocument jsonDoucmentTo(jsonObjectTo);
    QByteArray jsonTo = jsonDoucmentTo.toJson(QJsonDocument::Compact);
    u_socket->sendBinaryMessage(jsonTo);
}
