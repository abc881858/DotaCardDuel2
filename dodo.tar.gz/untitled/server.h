#ifndef SERVER_H
#define SERVER_H

#include <QObject>
#include <QWebSocketServer>
#include <QWebSocket>

#include "player.h"
#include <QDebug>

class Server : public QObject
{
    Q_OBJECT

public:
    explicit Server(QObject* parent = nullptr);
//    void write(QWebSocket *socket, QJsonObject jsonObject);
    void listen();

private:
    QWebSocketServer* server;
    QList<Player*> playerList;

public slots:
    void newConnection();
//    void readFromClient(QByteArray byteArray);
//    void readFromFirstClient(QByteArray byteArray);
//    void readFromSecondClient(QByteArray byteArray);
};

#endif // SERVER_H
