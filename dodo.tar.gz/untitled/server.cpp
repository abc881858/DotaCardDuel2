#include "server.h"

Server::Server(QObject *parent) : QObject(parent)
{
    server = new QWebSocketServer(QString("Card Server"), QWebSocketServer::NonSecureMode, this);
    connect(server, SIGNAL(newConnection()), this, SLOT(newConnection()));
}

void Server::listen()
{
    server->listen(QHostAddress::Any, 7720);
}

void Server::newConnection()
{
    qDebug() << "a client socket connected...";
    QWebSocket* socket = server->nextPendingConnection();

    Player *player = new Player(this);
    player->setSocket(socket);
    playerList.append(player);

    if(playerList.size() == 2)
    {
        playerList[0]->setOpponent(playerList[1]->socket());
        playerList[1]->setOpponent(playerList[0]->socket());
        playerList[0]->command_start_game_blue();
    }
}
