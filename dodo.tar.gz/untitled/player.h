#ifndef PLAYER_H
#define PLAYER_H

#include <QObject>
#include <QWebSocket>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

class Player : public QObject
{
    Q_OBJECT

public:
    enum StatusFlag
    {
        No_Status,
        Working_Status,
        Waiting_Status
    };

    explicit Player(QObject *parent = nullptr);
    void setSocket(QWebSocket *socket);
    QWebSocket *socket();

    void command_start_game_blue();
    void setOpponent(QWebSocket *socket);

private:
    QWebSocket *m_socket;
    QWebSocket *u_socket;

signals:

public slots:
    void readFromClient(const QByteArray& json);
};

#endif // PLAYER_H
